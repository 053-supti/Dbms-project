<?php 
	session_start();
	unset($_SESSION["teacher"]);
 ?>
 <script type="text/javascript">
 	window.location="login.php";
 </script>