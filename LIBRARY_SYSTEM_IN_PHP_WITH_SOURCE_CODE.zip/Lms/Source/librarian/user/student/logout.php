<?php 
	session_start();
	unset($_SESSION["student"]);
 ?>
 <script type="text/javascript">
 	window.location="login.php";
 </script>