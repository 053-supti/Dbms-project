
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Thank you for registration</title>
    <link rel="stylesheet" href="inc/css/bootstrap.min.css">
    <style>
        body{
            background: lightblue;
            padding: 100px;
        }
        .thankyou-content{
            width: 750px;
            margin: 0 auto;
        }
       p{
           margin-top: 30px;
       }

    </style>
</head>
<body>
    <div class="thankyou-content text-center">
        <h4>Your Email is verified..</h4>
        <h4>Now your account is under maintenance. After approve your account we will send you a email.</h4>
        <p><b>Thank you...</b></p>

    </div>

    <script src="inc/js/jquery-2.2.4.min.js"></script>
    <script src="inc/js/bootstrap.min.js"></script>
</body>
</html>







